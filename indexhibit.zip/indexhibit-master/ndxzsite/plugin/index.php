<?php if (!defined('SITE')) exit('No direct script access allowed');

// format help files
// we need an alternate formats file hook
load_plugin('formats');
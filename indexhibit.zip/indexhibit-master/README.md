# Indexhibit

Indexhibit is an archetypal portfolio CMS for everybody.

http://www.indexhibit.org

Sorry we're late to the Git party but here we are. Indexhibit needs quite alot of love - we'll be updating things with a roadmap shortly. Until then, feel free to help us make improvements.

Indexhibit is a registered trademark of Jeffery Vaska and Daniel Eatock.